class Greeting
{
    public static void Main()
    {
        Console.Write("Hi, Good Morning!");
        Console.WriteLine("3+6");
        Console.WriteLine(3 + 6);

        Console.WriteLine("Enter you name: ");
        string name = Console.ReadLine();
        Console.WriteLine(name);
    }
}

//Take all values from user and prnt his introduction.
// Take 2 values from user and concatenate them.
// print sum, sub, mul, div